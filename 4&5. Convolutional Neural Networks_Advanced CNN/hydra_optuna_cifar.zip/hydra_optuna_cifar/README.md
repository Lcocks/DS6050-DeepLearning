# Hydra + Optuna (Colab-ready) Demo

This mini-project converts the **slides** into **code**. It shows:
1) **Hydra** for configuration + multirun ablations (the research questions), and  
2) **Optuna** for *best-of-each* tuning (continuous/log training knobs).

## How to run on Colab

```bash
# 0) Upload this folder (or the ZIP) to Colab, then:
%pip install -q hydra-core hydra-optuna-sweeper optuna torch torchvision

# 1) Enter the project
%cd hydra_optuna_cifar

# 2) Single run (no sweeper), override from CLI
!python train.py training.epochs=3 optimizer.lr=3e-4 data.batch_size=64

# 3) Factorial ablation (Hydra multirun enumerates ≈ the "outer" questions)
!python train.py -m model.norm_type=none,batch,layer model.use_residual=true,false                  data.batch_size=32,64 hpo.seeds=[0,1]

# 4) HPO (Hydra Optuna Sweeper) = "best-of-each" tuning per design
!python train.py -m +experiment=hpo hpo.seeds=[0,1,2]
```

### Notes
- The **sweeper** (YAML) is great for search spaces but can't report per-epoch metrics for pruning.  
- If you want **per-epoch pruning**, flip `hpo.mode: "optuna_programmatic"` (see code comments), and run the inner Optuna loop programmatically.

### Files
- `conf/config.yaml` — Base config (seeds, data/model/opt/training knobs).
- `conf/experiment/hpo.yaml` — Hydra Optuna Sweeper (search spaces + TPE).
- `conf/experiment/ablate.yaml` — Example ablation toggles (grid/factorial).
- `train.py` — Hydra entrypoint; seed-averaged objective; optional programmatic Optuna.
- `models.py` — MLP with BN/LN/None + residual blocks (simple but clear).
- `data.py` — CIFAR-10 loader; also supports `FakeData` for offline smoke tests.
- `utils.py` — Seeding, param counting, and small helpers.

### The Story
- **Hydra** enumerates a *small set of architectures* you care about (e.g., norm type, residual on/off).  
- **Optuna** tunes *training knobs* (LR, WD, dropout, batch size) **for each architecture**, so comparisons are **fair** (each design competes at its own tuned optimum).
