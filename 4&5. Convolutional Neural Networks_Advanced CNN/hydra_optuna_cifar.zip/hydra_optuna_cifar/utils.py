import os, random, time
import numpy as np
import torch

def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def count_params(model) -> int:
    return sum(p.numel() for p in model.parameters())

def device_from_cfg(cfg) -> torch.device:
    if cfg.training.device == "cuda":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if cfg.training.device == "cpu":
        return torch.device("cpu")
    # "auto"
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")
