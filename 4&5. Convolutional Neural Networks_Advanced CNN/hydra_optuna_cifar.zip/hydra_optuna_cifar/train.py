# Hydra entrypoint that supports two "HPO modes":
# 1) hpo.mode == "none"  -> Just run a single (seed-averaged) evaluation. Use Hydra sweeper for HPO.
# 2) hpo.mode == "optuna_programmatic" -> Drive Optuna *inside* Python to enable per-epoch pruning.
#
# The "slides in code" mapping:
# - Hydra enumerates research configs (outer ablation): norms, residuals, init, depth.
# - Optuna tunes training knobs (inner): LR, WD, dropout, batch size.
# - Report each design at its *own tuned optimum* (mean ± std over seeds).

import os, math, time, random
import numpy as np
import torch
import hydra
from omegaconf import DictConfig, OmegaConf

from data import make_loaders
from models import build_mlp
from utils import set_seed, count_params, device_from_cfg

def _init_weights(model, init_name: str):
    if init_name == "kaiming_normal":
        for m in model.modules():
            if isinstance(m, torch.nn.Linear):
                torch.nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                if m.bias is not None:
                    torch.nn.init.zeros_(m.bias)
    elif init_name == "xavier_uniform":
        for m in model.modules():
            if isinstance(m, torch.nn.Linear):
                torch.nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    torch.nn.init.zeros_(m.bias)

def run_once(cfg, seed):
    """
    One full training run with a given seed.
    Returns the best validation accuracy observed across epochs.
    """
    set_seed(seed)
    device = device_from_cfg(cfg)

    train_loader, val_loader = make_loaders(cfg)
    model = build_mlp(cfg).to(device)
    _init_weights(model, cfg.model.init)

    # Optimizer
    if cfg.optimizer.name == "Adam":
        opt = torch.optim.Adam(model.parameters(),
                               lr=cfg.optimizer.lr,
                               weight_decay=cfg.optimizer.weight_decay)
    elif cfg.optimizer.name == "SGD":
        opt = torch.optim.SGD(model.parameters(),
                              lr=cfg.optimizer.lr,
                              weight_decay=cfg.optimizer.weight_decay,
                              momentum=cfg.optimizer.momentum)
    else:
        opt = torch.optim.RMSprop(model.parameters(),
                                  lr=cfg.optimizer.lr,
                                  weight_decay=cfg.optimizer.weight_decay)

    ce = torch.nn.CrossEntropyLoss()
    best = 0.0
    for epoch in range(cfg.training.epochs):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            logits = model(xb)
            loss = ce(logits, yb)
            loss.backward()
            opt.step()

        # Evaluate on validation split
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for xb, yb in val_loader:
                xb, yb = xb.to(device), yb.to(device)
                pred = model(xb).argmax(dim=1)
                correct += (pred == yb).sum().item()
                total += yb.size(0)
        acc = correct / max(1, total)
        best = max(best, acc)

    return best, count_params(model)

def seed_average(cfg):
    """
    Averages validation accuracy across cfg.hpo.seeds.
    This is the basic objective Hyd/Opt tune against.
    """
    scores = []
    nparams = None
    for s in cfg.hpo.seeds:
        acc, p = run_once(cfg, s)
        scores.append(acc)
        nparams = p
    mean_acc = float(np.mean(scores))
    std_acc = float(np.std(scores))
    return mean_acc, std_acc, nparams

@hydra.main(version_base=None, config_path="conf", config_name="config")
def main(cfg: DictConfig) -> None:
    print("==== Resolved Config ====")
    print(OmegaConf.to_yaml(cfg))

    if cfg.hpo.mode == "optuna_programmatic":
        # Programmatic Optuna for per-epoch pruning demo.
        # For true per-epoch pruning, restructure run_once() to report metrics each epoch:
        #   trial.report(val_metric, step=epoch)
        #   if trial.should_prune(): raise TrialPruned()
        import optuna

        def objective(trial):
            # Treat "training knobs" as search variables
            cfg.optimizer.lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            cfg.optimizer.weight_decay = trial.suggest_float("weight_decay", 1e-6, 1e-2, log=True)
            cfg.model.dropout = trial.suggest_float("dropout", 0.0, 0.6)
            cfg.data.batch_size = trial.suggest_categorical("batch_size", [32, 64, 128])

            # Also consider some architecture toggles (optional)
            cfg.model.norm_type = trial.suggest_categorical("norm_type", ["none","batch","layer"])
            cfg.model.use_residual = trial.suggest_categorical("use_residual", [True, False])

            mean_acc, std_acc, _ = seed_average(cfg)
            return mean_acc

        study = optuna.create_study(direction="maximize",
                                    sampler=optuna.samplers.TPESampler(seed=42))
        study.optimize(objective, n_trials=20)
        print("Best value:", study.best_value)
        print("Best params:", study.best_params)

    else:
        # Plain seed-averaged evaluation (single config);
        # use Hydra Sweeper for HPO or Hydra multirun for ablations.
        mean_acc, std_acc, nparams = seed_average(cfg)
        print(f"[RESULT] val_acc_mean={mean_acc:.4f}  val_acc_std={std_acc:.4f}  params={nparams}")

if __name__ == "__main__":
    main()
