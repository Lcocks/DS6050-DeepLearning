import torch
import torch.nn as nn

def _norm(norm_type, dim):
    if norm_type == "batch": return nn.BatchNorm1d(dim)
    if norm_type == "layer": return nn.LayerNorm(dim)
    return nn.Identity()

class ResidBlock(nn.Module):
    """Two-layer residual block with optional BN/LN and dropout."""
    def __init__(self, dim, norm_type="batch", p=0.0):
        super().__init__()
        self.f = nn.Sequential(
            nn.Linear(dim, dim),
            _norm(norm_type, dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p),
            nn.Linear(dim, dim),
            _norm(norm_type, dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p),
        )
    def forward(self, x):
        return x + self.f(x)

class MLP(nn.Module):
    """Simple MLP backbone + linear head to keep the demo fast in Colab."""
    def __init__(self, input_size, hidden_size, n_layers, num_classes,
                 norm_type="batch", p=0.0, use_residual=True):
        super().__init__()
        layers = [
            nn.Linear(input_size, hidden_size),
            _norm(norm_type, hidden_size),
            nn.ReLU(inplace=True),
            nn.Dropout(p)
        ]
        # Add (n_layers - 1) hidden layers, residual or plain
        for _ in range(n_layers - 1):
            if use_residual:
                layers.append(ResidBlock(hidden_size, norm_type, p))
            else:
                layers += [
                    nn.Linear(hidden_size, hidden_size),
                    _norm(norm_type, hidden_size),
                    nn.ReLU(inplace=True),
                    nn.Dropout(p)
                ]
        self.backbone = nn.Sequential(*layers)
        self.head = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        x = x.view(x.size(0), -1)  # flatten CIFAR images
        return self.head(self.backbone(x))

def build_mlp(cfg):
    return MLP(cfg.model.input_size, cfg.model.hidden_size,
               cfg.model.n_layers, cfg.model.num_classes,
               cfg.model.norm_type, cfg.model.dropout, cfg.model.use_residual)
