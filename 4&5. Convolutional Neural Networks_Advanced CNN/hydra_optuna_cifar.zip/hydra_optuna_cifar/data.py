import torch
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms

def make_loaders(cfg):
    """
    Returns train/val loaders. If cfg.data.use_fake is True, we use FakeData
    (handy when offline). Otherwise, we download CIFAR-10.
    """
    tfm = [transforms.ToTensor(),
           transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))]
    if cfg.data.augment:
        tfm = [transforms.RandomHorizontalFlip(),
               transforms.RandomCrop(32, padding=4)] + tfm
    tfm = transforms.Compose(tfm)

    if cfg.data.use_fake:
        full_train = datasets.FakeData(
            size=10000, image_size=(3,32,32), num_classes=10, transform=tfm)
        test = datasets.FakeData(
            size=2000, image_size=(3,32,32), num_classes=10, transform=tfm)
    else:
        full_train = datasets.CIFAR10(cfg.data.root, train=True,
                                      download=True, transform=tfm)
        test = datasets.CIFAR10(cfg.data.root, train=False,
                                download=True, transform=tfm)

    n_train = int(0.8 * len(full_train))
    n_val = len(full_train) - n_train
    train_set, val_set = random_split(full_train, [n_train, n_val])

    train_loader = DataLoader(train_set, batch_size=cfg.data.batch_size,
                              shuffle=True, num_workers=cfg.data.num_workers,
                              pin_memory=True)
    val_loader = DataLoader(val_set, batch_size=cfg.data.batch_size,
                            shuffle=False, num_workers=cfg.data.num_workers,
                            pin_memory=True)
    return train_loader, val_loader
